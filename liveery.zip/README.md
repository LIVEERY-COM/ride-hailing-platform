# Ride-hailing platform: project kit

A student-built ride-hailing platform (rider app, driver app, API, admin tools), planned for delivery by **26 February 2027** using agile practice, test-driven development, and an architecture designed to absorb change.

## Read this first: honest scope

You are 100-level students with about 21 weeks. That is enough to build a **well-engineered, well-tested, deployed MVP and run a small supervised closed beta**. It is not enough to out-scale an established company, and pretending otherwise would push you toward shortcuts. The goal here is the opposite: a smaller product built properly.

**Safety boundary.** This software is meant to carry people. Do not put real, unconnected members of the public in cars using it. Public operation needs regulatory approval, driver vetting, insurance, and legal advice that this project does not provide. The v1.0 target is a supervised closed beta with consenting participants and a supervisor's approval (see issue M9).

**Get a supervisor.** Ask a lecturer, a senior student, or a working engineer to review your pull requests weekly and your security work at M7. It is the single best way to learn faster and build safer.

## The stack (trimmed for a student team)

| Layer | Choice | Deferred until needed |
|---|---|---|
| Mobile | Flutter (one app, rider and driver modes) | Native Kotlin driver app |
| Backend | TypeScript with NestJS, modular monolith | Go dispatch service |
| Database | PostgreSQL | PostGIS, ClickHouse |
| Live data | Redis (driver locations, OTP, rate limits) | Kafka |
| Realtime | WebSockets | MQTT |
| Maps | flutter_map + OpenStreetMap; Haversine, then OSRM | Google Maps |
| Payments | Cash, plus Paystack in test mode | Multiple gateways, live money |
| Infra | Docker Compose, GitHub Actions, one staging server | Kubernetes |

Everything in the "deferred" column sits behind an interface (a *port*) so you can add it later without a rewrite. See `docs/ARCHITECTURE.md` for the triggers that tell you when to adopt each one.

## How to use this kit

1. Create an empty GitHub repository (private is fine) and clone it.
2. Copy this kit's contents into the clone and commit it.
3. Install the [GitHub CLI](https://cli.github.com) and run `gh auth login`.
4. Preview: `python3 scripts/bootstrap_github.py --dry-run`
5. Create everything: `python3 scripts/bootstrap_github.py`
   This creates 19 labels, 10 milestones with due dates, and 71 issues. It is safe to re-run.
6. In GitHub, create a **Project** (Board layout) with columns Backlog, Ready, In progress, In review, Done. Add all issues to it.
7. Work through `docs/ROADMAP.md` one sprint at a time, following `docs/ENGINEERING_HANDBOOK.md`.

## What is in here

| Path | Purpose |
|---|---|
| `docs/ROADMAP.md` | Sprint calendar, milestones, exit criteria, learning focus, and what to cut if you fall behind |
| `docs/ENGINEERING_HANDBOOK.md` | Agile process, TDD, Git workflow, Definitions of Ready and Done, safety and security rules |
| `docs/ARCHITECTURE.md` | Modules, ports, trip state machine, and how future changes plug in |
| `docs/BACKLOG.md` | Readable list of all issues by milestone |
| `docs/adr/` | Architecture Decision Record template |
| `backlog.json` | Source data for the bootstrap script |
| `.github/` | Issue and pull request templates |

## Planned repo layout (you create this in M0 and M1)

```
apps/api/        NestJS backend
apps/mobile/     Flutter app
infra/           docker-compose.yml, deployment files
docs/            everything above
scripts/         bootstrap and simulators
```
